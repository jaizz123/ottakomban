const fs = require('fs')
const path = require('path')

const outDir = path.join(process.cwd(), 'out')

// Function to rename folders to .html files
function convertToHtmlFiles() {
  const directories = ['about', 'services', 'contact']
  
  directories.forEach(dir => {
    const dirPath = path.join(outDir, dir)
    const htmlFile = path.join(outDir, `${dir}.html`)
    const indexFile = path.join(dirPath, 'index.html')
    
    if (fs.existsSync(dirPath) && fs.existsSync(indexFile)) {
      // Copy index.html to [dir].html
      fs.copyFileSync(indexFile, htmlFile)
      console.log(`Created ${dir}.html`)
      
      // Remove the directory
      fs.rmSync(dirPath, { recursive: true, force: true })
      console.log(`Removed ${dir}/ directory`)
    }
  })
  
  // Update links in all HTML files to use .html extensions
  updateLinksInHtmlFiles()
}

function updateLinksInHtmlFiles() {
  const htmlFiles = ['index.html', 'about.html', 'services.html', 'contact.html']
  
  htmlFiles.forEach(file => {
    const filePath = path.join(outDir, file)
    if (fs.existsSync(filePath)) {
      let content = fs.readFileSync(filePath, 'utf8')
      
      // Update relative links to use .html extensions
      content = content.replace(/href="\.\/about\/"/g, 'href="./about.html"')
      content = content.replace(/href="\.\/services\/"/g, 'href="./services.html"')
      content = content.replace(/href="\.\/contact\/"/g, 'href="./contact.html"')
      content = content.replace(/href="\.\.\/"/g, 'href="./index.html"')
      content = content.replace(/href="\.\.\/contact\/"/g, 'href="./contact.html"')
      
      fs.writeFileSync(filePath, content)
      console.log(`Updated links in ${file}`)
    }
  })
}

convertToHtmlFiles()
console.log('Post-build processing complete!')