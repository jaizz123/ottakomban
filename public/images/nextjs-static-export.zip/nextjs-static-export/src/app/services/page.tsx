import Link from 'next/link'

export const metadata = {
  title: 'Services - Next.js Static Site',
  description: 'Our services and offerings',
}

export default function Services() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-zinc-200 pb-6 pt-8 backdrop-blur-2xl dark:from-zinc-800/30">
      <div className="max-w-4xl mx-auto px-4">
        <nav className="mb-8">
          <a href="../" className="text-blue-500 hover:text-blue-700 underline">
            ← Back to Home
          </a>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">Our Services</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Discover what we offer
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h2 className="text-2xl font-semibold mb-4">Web Development</h2>
            <p className="mb-4">
              Custom websites built with modern technologies like Next.js, React, and TypeScript.
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Static Site Generation</li>
              <li>Responsive Design</li>
              <li>SEO Optimization</li>
            </ul>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h2 className="text-2xl font-semibold mb-4">Hosting Solutions</h2>
            <p className="mb-4">
              Deploy your static sites on various hosting platforms with optimized configurations.
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Static Hosting</li>
              <li>CDN Integration</li>
              <li>Performance Optimization</li>
            </ul>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h2 className="text-2xl font-semibold mb-4">Consulting</h2>
            <p className="mb-4">
              Expert advice on choosing the right technologies and deployment strategies.
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Technology Assessment</li>
              <li>Performance Audits</li>
              <li>Migration Planning</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 text-center">
          <a
            href="../contact/"
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition-colors"
          >
            Get in Touch
          </a>
        </div>
      </div>
    </main>
  )
}