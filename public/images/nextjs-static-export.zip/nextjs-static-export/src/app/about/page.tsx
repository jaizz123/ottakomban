import Link from 'next/link'
import Image from 'next/image'

export const metadata = {
  title: 'About - Next.js Static Site',
  description: 'Learn more about our Next.js static site',
}

export default function About() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-zinc-200 pb-6 pt-8 backdrop-blur-2xl dark:from-zinc-800/30">
      <div className="max-w-4xl mx-auto px-4">
        <nav className="mb-8">
          <a href="../" className="text-blue-500 hover:text-blue-700 underline">
            ← Back to Home
          </a>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">About Us</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Learn more about this Next.js static site project
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-3xl font-semibold mb-4">Our Mission</h2>
            <p className="text-lg mb-4">
              This is a demonstration of how Next.js can be used to create 
              static websites that work perfectly on traditional hosting 
              platforms like Hostinger.
            </p>
            <p className="text-lg">
              By using Next.js static export functionality, we can leverage 
              modern React development while generating plain HTML, CSS, and 
              JavaScript files that work anywhere.
            </p>
          </div>
          <div className="flex justify-center items-center">
            <Image
              src="/about-image.jpg"
              alt="About us illustration"
              width={400}
              height={300}
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>

        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-8">
          <h2 className="text-3xl font-semibold mb-6 text-center">Features</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">Static Export</h3>
              <p>Generates static HTML files for any hosting platform</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">Modern Development</h3>
              <p>Uses React, TypeScript, and Tailwind CSS</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">Optimized Assets</h3>
              <p>All images, CSS, and JS files are properly linked</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}