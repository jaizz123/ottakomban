/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  distDir: 'out',
  images: {
    unoptimized: true,
  },
  // This ensures assets work when served from any path
  assetPrefix: 'https://www.ottakombann.com/demo',
  // If you're deploying to a subdirectory, uncomment and modify the line below
  // basePath: '/your-subdirectory',
  // assetPrefix: '/your-subdirectory',
}

module.exports = nextConfig